    $("#myAccount").click(function()
             {
                $("#acct").show();
    })